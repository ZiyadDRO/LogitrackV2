# LogiTrack V2 backlog

From the full audit on 2026-09-29. Line numbers are approximate; each item names the function or area to search for. Tick items as they're done, with a one-line note.

Conventions: `daysUntilReorder` null = no reorder date or stock not counted; -1 = one day overdue (NOT "none"). In JS `null <= 0` is true.

## Batch 1. One shared forecast request (done 2026-09-29)
- [x] Product page forecast request omitted stock_source / stock_counted_at (SkuDetailPanel.jsx buildUrl). **Fixed:** one builder, `forecastUrl` in src/lib/api.js, used by the product page and both Fleet requests.
- [x] Fleet page-load request omitted unit_cost, fees, protection, stock_counted_at (App.jsx loadSkuList). **Fixed:** same builder.
- [x] Exports sent no stockSource and the typed lead time (App.jsx buildExportSkus; main.py _export_view / export_all). **Fixed:** exports send merged params, the planned lead time, stockSource, stockCountedAt; export_all's scorecard body now carries stockSource, unitsOnOrder, onOrderEtaDays.
- [x] exports.py treated daysUntilReorder == -1 as "no reorder". **Fixed:** only None means none; one-day-overdue products are on the reorder sheet.
- [x] Displays used the typed lead time instead of the planned one (SkuDetailPanel coverage dates / gap warning / reorder banner / swing row / runway note; FleetViews reorder bands and cash-plan repeats). **Fixed:** all use planningLeadTime(...).days (App passes `leadTimeOf`).
- [x] "Use avg" / "Use P80" buttons did nothing once 3+ deliveries existed. **Fixed:** removed; the card marks what planning actually uses ("in use"), and when the lead time is pinned it offers "Plan on measured P80". The order-math card now reads the plan's source (measured / pinned / estimate / one-off).
- [x] Sidebar urgency badge ignored each product's lead time. **Fixed:** SkuListItem takes the planned lead time.

## Batch 2. Stock counts (done 2026-09-29)
- [x] A saved count timestamp ("...Z") crashed every later forecast with a 500 (units_sold_since). **Fixed:** converted to the store's time zone, then compared as a plain date.
- [x] Stock box confirmed a first count on the first keystroke. **Fixed:** confirm on Enter or leaving the box.
- [x] A counted stock of 0 never set alreadyOut. **Fixed:** counted zero = out of stock.
- [x] Inventory value included placeholder stock. **Fixed:** counted stock only, labelled when some products aren't counted.

## Batch 3. Status badges (done 2026-09-29)
- [x] With older sales data the scorecard counted demand for days already past (false "Stockout risk"). **Fixed:** `_from_today` in sc_score_one, same rule as get_forecast's fc_fwd.
- [x] Any open PO made a product Healthy. **Fixed:** the reorder countdown counts the PO from the day it lands; a PO too small or too late says "Order in transit won't cover it". Cover stays on-hand only. Clients that send no PO quantity keep the old behaviour.
- [x] buildScorecardBody ignored the one-off slow shipment while forecasts included it. **Fixed:** removed ignoreOneOff there (the backtest signature keeps it on purpose). The Fleet "reorder" pill also handles negative days.

Tests: engine_statsforecast/test_scorecard_consistency.py (fails on the old code, passes now).

## Batch 4. Dates and time zones (done 2026-09-29)
One rule now: exact moments stay in UTC; which DAY something belongs to is decided in the store's time zone (engine_statsforecast/store_clock.py). The zone: picked on the Closed days panel ("Store time zone"), else the connected store's own (Square location / Shopify shop), else Eastern Time (America/New_York, so EST/EDT switch automatically). The browser's zone no longer sets anything.
- [x] Browser worked in UTC (todayStr, formatDate, poEtaDays, modals, product page). **Fixed:** helpers.js todayStr/todayMs use the store's zone from /api/store-clock (App loads it; falls back to the browser's calendar date, never UTC). Header date, file names and the AI's "today" use it too.
- [x] Live accuracy graded a week before Saturday was over. **Fixed:** forecast_log.today uses the store's day.
- [x] Shopify orders dated by UTC. **Fixed:** the orders query also reads shop.ianaTimezone; orders are dated in it and "yesterday" is the shop's yesterday.
- [x] Sold-out hours over UTC days; arrivals dated by UTC day. **Fixed:** censoring, arrivals, stock_log coverage and live_actuals use store days.
- [x] (added) Nightly sync ran at 00:15 SERVER time. **Fixed:** runs on the store's wall clock.
- [x] (added) Square/Shopify report their zone at import; it's filed per workspace (closed_days.json "zones") and applied before ingesting.

Tests: engine_statsforecast/test_store_clock.py.

## Batch 5. Upload (done 2026-09-29)
- [x] drop_duplicates() dropped identical same-day sale lines (3 mugs → 1). **Fixed:** identical rows are kept and summed. Only a file whose whole block of rows repeats in order (pasted in 2-4 times) is collapsed, and the upload says so ("fileRepeatedTimes"). Same rule in backtest.load_dataframe.
- [x] Dates were guessed from the first row; day-first dates got swapped/dropped. **Fixed:** `_parse_dates` checks the whole column (ISO → first number > 12 = day-first → otherwise US, with a note). If more than 20% of dates can't be read, the upload is refused with a plain message instead of half-loading.
- [x] Blank stock became "1 unit from your file". **Fixed:** last known stock comes from the real figures (`_stock_raw`), is saved on the product (`last_known_stock`, persisted by catalog_store) and read by /api/skus. A product with no stock figures in a file that has a stock column no longer gets a column of filled-in 1s.
- [x] SKU codes read as numbers (leading zeros lost, spaces kept). **Fixed:** `_read_sheet` reads the SKU column as text; codes are trimmed.

Tests: engine_statsforecast/test_upload_parsing.py.

## Batch 6. Store switching: data safety (main.py)
NOTE: a draft of the first five items was written in the 2026-09-29 session and then taken back out (not tested, not delivered). The approach, in case it helps:
- new store import with "save": park WHATEVER is loaded (not only spreadsheets), clear the live catalog/backtest dirs and in-memory backtest state, pause the previous store; a one-off (unsaved) import while a store shows: pause it and `_swap_workspace(SHEETS, refit=False)` first
- deleting the showing store: if spreadsheets are parked, `_swap_workspace(SHEETS)`, else `set_showing(SHEETS)`; then drop the slot
- /api/upload while a store shows: pause it and swap to SHEETS before `_ingest`; return `storePaused` (label) and show it in App's upload note
- `_swap_workspace(refit=False)`: reset `_backtest_tier_cache`, `_backtest_exclusions`, `_last_backtest`, `_backtest_inputs`, rows/combos, then `_restore_backtest()`
- `_ws_epoch` counter bumped on every swap/set-aside; both backtest jobs record it at snapshot and discard their result if it changed
- [ ] Connecting a second store while one is in use deletes the first store's products (upload_from_source ~3077). Always set aside _current_slot() first.
- [ ] Deleting the showing store (~2797-2808) leaves "showing" unrecorded; a restart can then overwrite another store's set-aside copy. Record SHEETS.
- [ ] Spreadsheet upload while a store is in use merges into the store (~2235-2253, ~3044-3056). Switch to spreadsheets first or refuse; match UploadPanel.jsx.
- [ ] Import on a paused store wipes its measured protection levels (_swap_workspace refit=False ~2890). Reset in-memory backtest state and reload from disk.
- [ ] A backtest finishing after a workspace switch saves into the new workspace (~5911-5928). Record workspace + fingerprint at start; discard if changed.
- [ ] A paused store's live prices / stock readings leak into same-code spreadsheet products (~1904, ~2027, ~3518). Use them only while that store is showing.

## Batch 7. Product page editing
- [ ] draftParams only resets on product switch and saves whole (SkuDetailPanel ~330-361, ~503-506): after Mark received, any other edit puts stock back. Re-sync on params change or save only changed fields.
- [ ] Debounced save (~353, App.jsx ~1195) can write A's settings onto B; closing drops the pending save; stale forecast responses can show for the wrong product (~421-450). Bind sku id, flush on change/close, ignore stale responses.
- [ ] refreshSkuSummary / loadScorecardRows / loadSkuList miss `suppliers` in deps (App.jsx ~181-283). Add it and refresh on supplier changes.
- [ ] Events editor Save discards a filled-in, not-added event or an unconfirmed AI-parsed one (modals.jsx ~626).

## Batch 8. Purchase orders and suppliers
- [ ] One open PO per product: marking one order received cancels another (SupplierPanel.jsx ~194-197; SkuDetailPanel.jsx ~513-516). Link open PO ↔ supplier order id.
- [ ] Empty arrival date adds stock but leaves the order in transit (double add). Require a date.
- [ ] Logging an already-arrived past delivery adds it to today's stock (SupplierPanel.jsx ~171).
- [ ] Full report "Open POs" sheet always empty (exports.py ~597). Send openPOs and supplier orders.
- [ ] Supplier export lists "Unassigned orders" as a supplier. Filter it (namedSuppliers).

## Batch 9. Backtest correctness
- [ ] Untestable windows produce a "measured" Light 90% (_nanmean all-NaN → 0, backtest.py ~514/~999-1017; gate main.py ~6600; sync horizon fixed at 44 ~3365). Count only testable windows; no bestTier when none; horizon ≥ max lead + coverage. Same for rebuild_from_rows / recost.
- [ ] As-of-cutoff catalog (backtest.py ~145) drops price / price_mixed / price_listed / on_promotion from peer frames. Keep them.
- [ ] Scoring filters units_in_stock > 0 (backtest.py ~291, ~297): products with no stock column never tested and retrigger every sync. Treat blank as in stock.
- [ ] Scoring drops sold-out days that training keeps (~289-292). Exclude only UNAVAILABLE days.
- [ ] Calibration refits (main.py ~1643): `related` not cut to cutoff (leak); force_route and pool_cohesion not passed.
- [ ] "Re-test now" (BacktestTab.jsx ~371) sends no combos/holding; server uses 14/30/25% and wipes other products' tiers (main.py ~6310, ~6587). Use App's triggerBacktest.

## Batch 10. Backtest realism
- [ ] Test windows forecast with events=[] (backtest.py ~273). Build each window's price changes and promotions from its recorded price / on_promotion, same event shapes as the app.
- [ ] Shelf price changes don't reach the backtest's economics (margin at cutoff price ~311; _economics_drifted ~6558 checks cost/fees/holding only). Re-price stored results (recost, no refit) with the current price.
- [ ] Cost: current dashboard cost used for every window; _cost_as_of only when no dashboard cost (~312-315). Prefer cost as of each window when a history exists.

## Batch 11. Shopify
- [ ] fetch_catalog_meta (shopify_source.py ~269) asks products(first:100) × variants(first:100), far over Shopify's 1,000-point query limit. Page smaller; add a test on the query's estimated cost.

## Batch 12. Smaller logic fixes
- [ ] Grouping tab auto-classifies on mount and saves AI categories as user-set, replacing the file's Category (CategorizePanel.jsx ~183-195, ~276; main.py ~3995).
- [ ] bundles.py ~171 adds a kit's units to every row of the component that day. Once per (day, component).
- [ ] censoring.py ~233-258: last stock reading carried forward forever; dead guard at ~256; day with sales but 0 tracked hours dropped (~113).
- [ ] Holding-cost wizard matches "art" inside "parts" (holding.js / HoldingWizard.jsx). Whole words.

## Before a first client (plan and check with Z first)
- [ ] Move Groq calls behind the backend (key out of the browser bundle): ai.js, AiDrawer.jsx, CategorizePanel.jsx, modals.jsx AI parser.
- [ ] Square multi-location (square_source.py reads one; the cousin's store has 2).
